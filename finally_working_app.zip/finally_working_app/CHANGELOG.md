# Change Log
All notable changes to this project be documented in this file. This project tries to adhere to a [semantic versioning](https://semver.org/) scheme.

## [MAJOR.MINOR.PATCH] - TODAYS DATE
### Added

### Changed

### Fixed

### Removed
