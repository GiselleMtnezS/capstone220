import React from 'react';
import ReactDOM from 'react-dom';
// import './css/index.css';
import Navigation from './navigation/Nagivation';
// import {BrowserRouter as Router} from 'react-router-dom'

ReactDOM.render(<Navigation />, document.getElementById('root'));

// {/* <Router> </Router> */}
