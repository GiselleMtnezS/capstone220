import React ,{Component}from 'react'

export default class Location1 extends Component {
constructor(){
    super()
    this.state={}
}
render (){

return(
    <section>
        Location1
    </section>
)
}

}
