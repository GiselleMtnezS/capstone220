import React ,{Component}from 'react'

export default class Covid extends Component {
constructor(){
    super()
    this.state={}
}
render (){

return(
    <section>
        Covid
    </section>
)
}

}
