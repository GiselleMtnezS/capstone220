import React ,{Component}from 'react'

export default class Location2 extends Component {
constructor(){
    super()
    this.state={}
}
render (){

return(
    <section>
        Location2
    </section>
)
}

}
