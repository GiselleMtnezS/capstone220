import React ,{Component}from 'react'

export default class Locations extends Component {
constructor(){
    super()
    this.state={}
}
render (){

return(
    <section>
        Locations
    </section>
)
}

}
