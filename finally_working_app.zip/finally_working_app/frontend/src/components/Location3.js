import React ,{Component}from 'react'

export default class Location3 extends Component {
constructor(){
    super()
    this.state={}
}
render (){

return(
    <section>
        Location3
    </section>
)
}

}
