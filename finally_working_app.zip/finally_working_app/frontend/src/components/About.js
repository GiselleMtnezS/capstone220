import React ,{Component}from 'react'

export default class About extends Component {
constructor(){
    super()
    this.state={}
}
render (){

return(
    <section>
        About
    </section>
)
}

}
