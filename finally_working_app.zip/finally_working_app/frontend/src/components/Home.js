import React ,{Component}from 'react'

export default class Home extends Component {
constructor(){
    super()
    this.state={}
}
render (){

return(
    <section>
<div className="section-body">
      <h1>Welcome to our Tourism Site!</h1>

      <h2>We specialize in providing you the best and most up-to-date information about Location1, Location2, and Location 3</h2>

      <h3>If you need any assistance, please feel free to click on our 'About Us' page and send us a message. Thank you and have a great day!</h3>
  </div>
  <div className="section-body">
      <h1>Welcome to our Tourism Site!</h1>

      <h2>We specialize in providing you the best and most up-to-date information about Location1, Location2, and Location 3</h2>

      <h3>If you need any assistance, please feel free to click on our 'About Us' page and send us a message. Thank you and have a great day!</h3>
  </div><div className="section-body">
      <h1>Welcome to our Tourism Site!</h1>

      <h2>We specialize in providing you the best and most up-to-date information about Location1, Location2, and Location 3</h2>

      <h3>If you need any assistance, please feel free to click on our 'About Us' page and send us a message. Thank you and have a great day!</h3>
  </div><div className="section-body">
      <h1>Welcome to our Tourism Site!</h1>

      <h2>We specialize in providing you the best and most up-to-date information about Location1, Location2, and Location 3</h2>

      <h3>If you need any assistance, please feel free to click on our 'About Us' page and send us a message. Thank you and have a great day!</h3>
  </div><div className="section-body">
      <h1>Welcome to our Tourism Site!</h1>

      <h2>We specialize in providing you the best and most up-to-date information about Location1, Location2, and Location 3</h2>

      <h3>If you need any assistance, please feel free to click on our 'About Us' page and send us a message. Thank you and have a great day!</h3>
  </div><div className="section-body">
      <h1>Welcome to our Tourism Site!</h1>

      <h2>We specialize in providing you the best and most up-to-date information about Location1, Location2, and Location 3</h2>

      <h3>If you need any assistance, please feel free to click on our 'About Us' page and send us a message. Thank you and have a great day!</h3>
  </div><div className="section-body">
      <h1>Welcome to our Tourism Site!</h1>

      <h2>We specialize in providing you the best and most up-to-date information about Location1, Location2, and Location 3</h2>

      <h3>If you need any assistance, please feel free to click on our 'About Us' page and send us a message. Thank you and have a great day!</h3>
  </div>

        Home
    </section>
)
}

}

